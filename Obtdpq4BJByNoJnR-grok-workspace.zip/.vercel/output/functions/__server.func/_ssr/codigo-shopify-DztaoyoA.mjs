import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Copy, m as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/codigo-shopify-DztaoyoA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIT_FILES = [
	{
		path: "/shopify/customizer/liquid-announcement.html",
		title: "customizer/liquid-announcement.html",
		hint: "Cola no Liquid personalizado"
	},
	{
		path: "/shopify/templates/index.json",
		title: "templates/index.json",
		hint: "Ordem da homepage"
	},
	{
		path: "/shopify/assets/auconforto.css",
		title: "assets/auconforto.css",
		hint: "CSS da marca"
	},
	{
		path: "/shopify/sections/announcement-rotator.liquid",
		title: "announcement-rotator.liquid",
		hint: "Faixa 3 mensagens"
	},
	{
		path: "/shopify/sections/hero-auconforto.liquid",
		title: "hero-auconforto.liquid",
		hint: "1ª dobra"
	},
	{
		path: "/shopify/sections/trust-bar.liquid",
		title: "trust-bar.liquid",
		hint: "4 colunas"
	},
	{
		path: "/shopify/sections/featured-pets.liquid",
		title: "featured-pets.liquid",
		hint: "Os 4 + badges"
	},
	{
		path: "/shopify/sections/why-it-works.liquid",
		title: "why-it-works.liquid",
		hint: "Antes / depois"
	},
	{
		path: "/shopify/sections/faq-homepage.liquid",
		title: "faq-homepage.liquid",
		hint: "5 perguntas"
	},
	{
		path: "/shopify/sections/coupon-signup.liquid",
		title: "coupon-signup.liquid",
		hint: "VOLTA10"
	}
];
var CUSTOMIZER = [
	{
		title: "1. Announcement bar",
		body: `Dawn nativo só aceita 1 frase. Desliga a faixa nativa e usa a seção AC Announcement.

Textos rotativos (link: /collections/pets):
1. FRETE GRÁTIS ACIMA DE R$149 | PIX COM 5% OFF
2. 8-15 DIAS ÚTEIS COM RASTREIO | IMPOSTO INCLUSO
3. CUPOM VOLTA10 = 10% OFF NA PRIMEIRA COMPRA`
	},
	{
		title: "2. Header",
		body: `Logo: AuConforto (texto, sem imagem)
Menu: Início (/) · Loja (/collections/pets) · Gatos (/collections/gatos) · Rastrear Pedido (/pages/rastrear-pedido) · Ajuda (/pages/ajuda)
Busca ON · Conta OFF · Carrinho drawer ON`
	},
	{
		title: "3. Hero — Image banner",
		body: `Título: Apartamento com pet não precisa viver com pelo, calor e tédio
Sub: 4 soluções testadas pra cães e gatos em apê. Pix com desconto, rastreio incluso, 7 dias de garantia.
Botão 1: Ver os 4 mais vendidos → /collections/pets
Botão 2: Rastrear meu pedido → /pages/rastrear-pedido
Mobile: texto centralizado
Linha sob os botões: Pix com desconto · 8–15 dias úteis com rastreio · 7 dias contra defeito`
	},
	{
		title: "4. Trust — Multicolumn 4",
		body: `1. Rastreio incluso — Código em até 48h no WhatsApp/e-mail
2. Pix + cartão 3x — Via Mercado Pago, boleto OFF
3. 7 dias de garantia — Vídeo do defeito = troca
4. Feito pra apê — Testado em gato/cão de apartamento`
	},
	{
		title: "5. Featured collection Pets",
		body: `Título: Os 4 que mais saem pra quem mora em apê
Sub: Escolhe pela tua dor. Frete grátis acima de R$149.
Ordem: Escova a Vapor · Pente Mágico · Moinho Giratório · Tapete Gel XS
Tags: mais-vendido (1 e 2), pra-gatos (3)
Botão: Ver tudo → /collections/pets`
	},
	{
		title: "6. Por que funciona",
		body: `Bloco A — Pelo
Título: 5 min por dia, 80% menos pelo no sofá
Texto: Pente + Escova Vapor tiram o subpelo que aspirador não pega. Sem puxar, sem machucar. Gato ronrona, cachorro fica quieto.
CTA: Quero casa sem pelo → Escova a Vapor

Bloco B — Tédio + calor
Título: Gato sozinho não precisa destruir o sofá
Texto: Moinho cansa em 15 min sem você. Tapete Gel alivia o calor sem molhar, sem geladeira, sem energia.
CTA: Quero gato tranquilo → Moinho`
	},
	{
		title: "8. FAQ",
		body: `1. Quando chega? → 8-15 dias úteis com rastreio. Código em até 48h após pagamento.
2. Frete? → R$9,90 fixo com rastreio, grátis acima de R$149. Imposto incluso.
3. E se quebrar? → 7 dias com vídeo = troca ou reembolso. Sem devolução se custo <70.
4. Pix tem desconto? → Sim, 5% OFF automático + cupom VOLTA10 na primeira compra.
5. Serve pro meu pet? → Pente/Escova: cães/gatos pelo curto/médio. Moinho: gatos. Tapete XS: até 5kg.`
	},
	{
		title: "9. Newsletter",
		body: `Título: Ganha 10% OFF na primeira compra
Texto: Deixa teu e-mail e recebe VOLTA10 + rastreio sem enrolação.
Botão: Quero meu cupom
Shopify Email + automação carrinho 1h / 24h / 72h`
	},
	{
		title: "10. Footer",
		body: `Coluna 1: AuConforto — Conforto pra pets em apartamento. Pix + cartão 3x, rastreio incluso.
Coluna 2 Loja: Todos os produtos · Gatos · Rastrear pedido · Fale conosco
Coluna 3 Ajuda: Prazo · Trocas · Privacidade · Termos · Reembolso
Pagamento: Pix, Visa, Master, Mercado Pago
© AuConforto — CNPJ em regularização MEI. Suporte em até 24h úteis.`
	}
];
function ShopifyKitPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-4xl px-4 py-12 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
				children: "Tema Dawn"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-4xl font-semibold tracking-tight",
				children: "Código Shopify da homepage"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-muted",
				children: "Copia a ordem, a copy e as seções Liquid pra colar no Dawn. O preview desta página é o visual alvo — o código abaixo é o que vai pro Customizer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/shopify-auconforto-dawn.zip",
				download: true,
				className: "mt-6 inline-flex min-h-12 items-center justify-center rounded-md bg-primary px-5 text-sm font-semibold text-primary-fg",
				children: "Baixar zip das seções Dawn"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-8 space-y-3 rounded-xl bg-surface p-5 text-sm leading-relaxed shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Duplica o tema Dawn." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"2. Em Editar código, cola ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-fg",
							children: "assets/auconforto.css"
						}),
						" e as 7 seções."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"3. Substitui ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-fg",
							children: "templates/index.json"
						}),
						" pelo arquivo desta pasta."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4. Cria coleções manuais Pets / Gatos / pagina-inicial e as páginas de ajuda." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "5. Menu principal e rodapé nos handles da copy. Conta OFF, busca ON, drawer ON." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-14 text-2xl font-semibold",
				children: "Copy do Customizer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-4",
				children: CUSTOMIZER.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyCard, {
					title: block.title,
					body: block.body
				}, block.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-14 text-2xl font-semibold",
				children: "Arquivos Liquid"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 mb-5 text-sm text-muted",
				children: "Abre, copia, cola no tema. Nome do arquivo = tipo da seção no Customizer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: KIT_FILES.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCard, { file }, file.path))
			})
		]
	});
}
function CopyCard({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: body })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-3 overflow-x-auto whitespace-pre-wrap font-sans text-sm leading-relaxed text-muted",
			children: body
		})]
	});
}
function FileCard({ file }) {
	const [text, setText] = (0, import_react.useState)("Carregando…");
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		fetch(file.path).then((r) => r.ok ? r.text() : Promise.reject()).then((t) => {
			if (alive) setText(t);
		}).catch(() => {
			if (alive) setText("Não deu pra carregar este arquivo.");
		});
		return () => {
			alive = false;
		};
	}, [file.path]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3 px-5 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: file.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: file.hint
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: text.startsWith("Carreg") || text.startsWith("Não") ? "" : text }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-10 rounded-md border border-border px-3 text-sm",
					onClick: () => setOpen((v) => !v),
					children: open ? "Fechar" : "Ver código"
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "max-h-96 overflow-auto border-t border-border bg-fg p-4 text-[11px] leading-relaxed text-primary-fg",
			children: text
		}) : null]
	});
}
function CopyButton({ text }) {
	const [ok, setOk] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled: !text,
		className: "inline-flex min-h-10 items-center gap-1.5 rounded-md border border-border px-3 text-sm font-medium disabled:opacity-40",
		onClick: async () => {
			await navigator.clipboard.writeText(text);
			setOk(true);
			setTimeout(() => setOk(false), 1600);
		},
		children: [ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), ok ? "Copiado" : "Copiar"]
	});
}
//#endregion
export { ShopifyKitPage as component };
