import { B as require_jsx_runtime, y as Link, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as productsByHandles, i as Route$2, o as COLLECTIONS } from "./router-pGuTO8jO.mjs";
import { t as ProductCard } from "./product-card-D8cUPilU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/collections._slug-CwT-R435.js
var import_jsx_runtime = require_jsx_runtime();
function CollectionPage() {
	const { slug } = Route$2.useParams();
	const col = COLLECTIONS[slug];
	if (!col) throw notFound();
	const products = productsByHandles(col.handles);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
				children: "Coleção"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-4xl font-semibold tracking-tight",
				children: col.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: col.seo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
				children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
					product: p,
					featured: true
				}, p.handle))
			}),
			slug !== "pets" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-12 text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/collections/$slug",
					params: { slug: "pets" },
					className: "font-medium underline",
					children: "Ver todos os produtos"
				})
			}) : null
		]
	});
}
//#endregion
export { CollectionPage as component };
