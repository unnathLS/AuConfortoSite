import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as ChevronDown } from "../_libs/lucide-react.mjs";
import { f as cn, s as FAQS } from "./router-pGuTO8jO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-list-7l8YLF9Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FaqList() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "divide-y divide-border border-y border-border",
		children: FAQS.map((item, i) => {
			const isOpen = open === i;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex min-h-14 w-full items-center justify-between gap-4 py-4 text-left",
				"aria-expanded": isOpen,
				onClick: () => setOpen(isOpen ? null : i),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg font-medium",
					children: item.q
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-5 shrink-0 text-muted transition-transform duration-200", isOpen && "rotate-180") })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("grid transition-[grid-template-rows] duration-200 ease-out", isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "overflow-hidden pb-4 text-sm leading-relaxed text-muted",
					children: item.a
				})
			})] }, item.q);
		})
	});
}
//#endregion
export { FaqList as t };
