import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react, y as Link, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as HELP_PAGES, r as Route$1 } from "./router-pGuTO8jO.mjs";
import { t as FaqList } from "./faq-list-7l8YLF9Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pages._slug-Bw3p6r3r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HelpPage() {
	const { slug } = Route$1.useParams();
	const page = HELP_PAGES[slug];
	if (!page) throw notFound();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
				children: page.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-4xl font-semibold tracking-tight",
				children: page.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-5 text-[15px] leading-relaxed text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageBody, { slug })
			})
		]
	});
}
function PageBody({ slug }) {
	if (slug === "rastrear-pedido") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackForm, {});
	if (slug === "ajuda") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "As 5 perguntas que o suporte responde todo dia. Se não estiver aqui, manda WhatsApp." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "pt-4",
			children: [
				"Ainda travado?",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pages/$slug",
					params: { slug: "contato" },
					className: "font-medium text-fg underline",
					children: "Fale conosco"
				}),
				"."
			]
		})
	] });
	if (slug === "prazo-de-entrega") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "8 a 15 dias úteis com rastreio. Imposto incluso — não tem taxa na porta." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "O código de rastreio sai em até 48h após o pagamento, no WhatsApp ou no e-mail da compra." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Frete R$9,90 fixo. Grátis acima de R$149." })
	] });
	if (slug === "trocas-e-garantia" || slug === "reembolso") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "7 dias contra defeito. Manda um vídeo curto mostrando o problema: troca ou reembolso." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Se o custo de devolver o produto for menor que R$70, não pedimos a devolução física — resolvemos no Pix ou na troca." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Arrependimento: mesma janela de 7 dias, produto sem uso, na caixa." })
	] });
	if (slug === "privacidade") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Usamos teu e-mail e WhatsApp só pra pedido, rastreio e o cupom VOLTA10. Sem lista vendida, sem spam de terceiros." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pagamento passa pelo Mercado Pago. Não guardamos número de cartão neste site." })] });
	if (slug === "termos") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "AuConforto vende soluções pra pets em apartamento. Pedidos sujeitos a estoque. Preços em reais, imposto incluso no frete declarado." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "CNPJ em regularização MEI. Suporte em até 24h úteis." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Suporte em até 24h úteis. WhatsApp e e-mail do pedido." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Assunto que resolve mais rápido: número do pedido + foto ou vídeo." })] });
}
function TrackForm() {
	const [code, setCode] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-4",
		onSubmit: (e) => {
			e.preventDefault();
			toast.message("Rastreio", { description: `Código ${code.toUpperCase()} — assim que o fulfillment disparar, o link dos Correios / 17track aparece no teu e-mail em até 48h.` });
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cola o código que chegou no WhatsApp ou e-mail. Se ainda não chegou, espera 48h após o Pix confirmar." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-sm font-medium text-fg",
				htmlFor: "track",
				children: "Código de rastreio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "track",
				value: code,
				onChange: (e) => setCode(e.target.value),
				required: true,
				placeholder: "AA123456789BR",
				className: "h-12 w-full rounded-md border border-border bg-surface px-3 text-fg outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex min-h-12 items-center justify-center rounded-md bg-primary px-6 text-sm font-semibold text-primary-fg",
				children: "Rastrear"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Sem código?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pages/$slug",
						params: { slug: "contato" },
						className: "text-fg underline",
						children: "Fale conosco"
					})
				]
			})
		]
	});
}
//#endregion
export { HelpPage as component };
