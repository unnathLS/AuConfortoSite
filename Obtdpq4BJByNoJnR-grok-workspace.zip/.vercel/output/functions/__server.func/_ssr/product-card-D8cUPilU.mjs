import { B as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCart, f as cn, p as formatBRL } from "./router-pGuTO8jO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-D8cUPilU.js
var import_jsx_runtime = require_jsx_runtime();
var BADGE_LABEL = {
	"mais-vendido": "Mais vendido",
	"pra-gatos": "Pra gatos"
};
function ProductCard({ product, featured }) {
	const add = useCart((s) => s.add);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/products/$handle",
			params: { handle: product.handle },
			className: "relative block overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: featured ? product.lifestyle : product.image,
				alt: product.title,
				className: "aspect-square w-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03]"
			}), product.badges[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-3 left-3 rounded-full bg-fg px-2.5 py-1 text-[10px] font-semibold tracking-[0.12em] text-primary-fg uppercase",
				children: BADGE_LABEL[product.badges[0]]
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: product.pain
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products/$handle",
					params: { handle: product.handle },
					className: "font-display mt-1 text-xl font-semibold tracking-tight text-fg",
					children: product.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: product.short
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-base font-semibold tabular-nums",
						children: formatBRL(product.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted line-through tabular-nums",
						children: formatBRL(product.compareAt)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						add(product.handle);
						toast.success(`${product.title} no carrinho`);
					},
					className: cn("mt-4 inline-flex min-h-11 items-center justify-center rounded-md bg-fg px-4 text-sm font-semibold text-primary-fg", "transition-transform duration-150 ease-out active:scale-[0.96]"),
					children: "Adicionar"
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
