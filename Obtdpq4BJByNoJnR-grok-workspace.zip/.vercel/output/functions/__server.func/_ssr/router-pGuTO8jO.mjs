import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react, _ as createFileRoute, b as useRouter, d as HeadContent, f as useRouterState, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Minus, i as ShoppingBag, l as Menu, o as Search, r as TriangleAlert, s as Plus, t as X } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-DM1Nxth5.js
var PRODUCTS = [
	{
		handle: "escova-a-vapor",
		title: "Escova a Vapor",
		short: "Tira o subpelo que o aspirador não pega",
		pain: "Pelo no sofá",
		price: 189.9,
		compareAt: 249.9,
		badges: ["mais-vendido"],
		image: "/images/escova-pack.jpg",
		lifestyle: "/images/escova-lifestyle.jpg",
		forCats: true,
		forDogs: true,
		weightNote: "Cães e gatos de pelo curto ou médio",
		bullets: [
			"Vapor suave solta o subpelo sem puxar",
			"5 minutos por dia, 80% menos pelo no sofá",
			"Gato ronrona, cachorro fica quieto",
			"Demo forte — o pelo sai na hora"
		],
		description: "A Escova a Vapor é o hero de quem mora em apê. O vapor abre o pelo e solta o subpelo que aspirador, rolo adesivo e pente comum não pegam. Sem machucar, sem barulho de secador, sem levar o pet no pet shop. Cinco minutos no colo do sofá e a casa para de parecer um tapete."
	},
	{
		handle: "pente-magico",
		title: "Pente Mágico",
		short: "Entrada barata pra parar o pelo agora",
		pain: "Pelo no sofá",
		price: 99.9,
		compareAt: 139.9,
		badges: ["mais-vendido"],
		image: "/images/pente-pack.jpg",
		lifestyle: "/images/pente-lifestyle.jpg",
		forCats: true,
		forDogs: true,
		weightNote: "Cães e gatos de pelo curto ou médio",
		bullets: [
			"Dentes arredondados, não puxa a pele",
			"Leva o pelo morto numa passada",
			"Cabe na gaveta, usa todo dia",
			"Combina com a Escova a Vapor no combo"
		],
		description: "O Pente Mágico é a porta de entrada: R$99,90, resultado na primeira passada. Tira o pelo morto da superfície enquanto a Escova a Vapor trabalha o subpelo. Quem mora em apê pequeno sente a diferença no sofá no mesmo dia."
	},
	{
		handle: "moinho-giratorio",
		title: "Moinho Giratório",
		short: "Cansa o gato em 15 min sem você",
		pain: "Tédio / sofá destruído",
		price: 129.9,
		compareAt: 179.9,
		badges: ["pra-gatos"],
		image: "/images/moinho-pack.jpg",
		lifestyle: "/images/moinho-lifestyle.jpg",
		forCats: true,
		forDogs: false,
		weightNote: "Gatos",
		bullets: [
			"Gira com petisco e cansa de verdade",
			"Gato sozinho para de atacar o sofá",
			"Sem pilha, sem app, sem barulho de motor",
			"Cabe no canto do apê"
		],
		description: "Gato sozinho no apê não precisa destruir o sofá. O Moinho Giratório gira com petisco, obriga o gato a caçar e cansa em cerca de 15 minutos. Sem você no chão brincando de laserzinho depois do expediente."
	},
	{
		handle: "tapete-gel-xs",
		title: "Tapete Gel XS",
		short: "Alivia o calor sem molhar e sem energia",
		pain: "Calor no apê",
		price: 79.9,
		compareAt: 119.9,
		badges: [],
		image: "/images/tapete-lifestyle.jpg",
		lifestyle: "/images/tapete-lifestyle.jpg",
		forCats: true,
		forDogs: true,
		weightNote: "Pets até 5 kg",
		bullets: [
			"Gel que esfria sozinho, sem geladeira",
			"Não molha o chão, não gasta energia",
			"Tamanho XS pra apê e pet pequeno",
			"Verão em concreto: o chão queima, o tapete não"
		],
		description: "Apê no verão vira forno. O Tapete Gel XS esfria o pet sem molhar, sem geladeira e sem tomada. Tamanho extra-pequeno pra quem tem até 5 kg — gato, maltês, york, shih-tzu filhote."
	}
];
var PRODUCT_ORDER_HOME = [
	"escova-a-vapor",
	"pente-magico",
	"moinho-giratorio",
	"tapete-gel-xs"
];
var PRODUCT_ORDER_CATS = [
	"moinho-giratorio",
	"tapete-gel-xs",
	"pente-magico",
	"escova-a-vapor"
];
function getProduct(handle) {
	return PRODUCTS.find((p) => p.handle === handle);
}
function productsByHandles(handles) {
	return handles.map((h) => getProduct(h)).filter((p) => Boolean(p));
}
var COLLECTIONS = {
	pets: {
		slug: "pets",
		title: "Os 4 que resolvem",
		seo: "Soluções pra cães e gatos em apartamento: sem pelo, sem calor, sem tédio. Pix com desconto, 8-15 dias com rastreio.",
		handles: PRODUCT_ORDER_HOME
	},
	gatos: {
		slug: "gatos",
		title: "Pra gatos em apê",
		seo: "Moinho, tapete gel, pente e escova a vapor — ordem pensada pra gato de apartamento.",
		handles: PRODUCT_ORDER_CATS
	},
	"pagina-inicial": {
		slug: "pagina-inicial",
		title: "Mais vendidos",
		seo: "Os 4 mais vendidos da AuConforto pra quem mora em apartamento com pet.",
		handles: PRODUCT_ORDER_HOME
	}
};
var ANNOUNCEMENTS = [
	"FRETE GRÁTIS ACIMA DE R$149  ·  PIX COM 5% OFF",
	"8–15 DIAS ÚTEIS COM RASTREIO  ·  IMPOSTO INCLUSO",
	"CUPOM VOLTA10 = 10% OFF NA PRIMEIRA COMPRA"
];
var TRUST = [
	{
		title: "Rastreio incluso",
		text: "Código em até 48h no WhatsApp ou e-mail",
		icon: "truck"
	},
	{
		title: "Pix + cartão 3x",
		text: "Via Mercado Pago. Boleto off.",
		icon: "card"
	},
	{
		title: "7 dias de garantia",
		text: "Vídeo do defeito = troca. Sem drama.",
		icon: "shield"
	},
	{
		title: "Feito pra apê",
		text: "Testado em gato e cão de apartamento",
		icon: "home"
	}
];
var FAQS = [
	{
		q: "Quando chega?",
		a: "8 a 15 dias úteis com rastreio. O código sai em até 48h após o pagamento, no WhatsApp ou no e-mail."
	},
	{
		q: "Como é o frete?",
		a: "R$9,90 fixo com rastreio. Grátis acima de R$149. Imposto incluso — não tem surpresa na porta."
	},
	{
		q: "E se quebrar?",
		a: "7 dias com vídeo do defeito = troca ou reembolso. Sem devolução física se o custo do envio for menor que R$70."
	},
	{
		q: "Pix tem desconto?",
		a: "Sim. 5% OFF automático no Pix, mais o cupom VOLTA10 na primeira compra."
	},
	{
		q: "Serve pro meu pet?",
		a: "Pente e Escova: cães e gatos de pelo curto ou médio. Moinho: gatos. Tapete Gel XS: até 5 kg."
	}
];
var HELP_PAGES = {
	"rastrear-pedido": {
		title: "Rastrear pedido",
		kicker: "Rastreio"
	},
	ajuda: {
		title: "Ajuda",
		kicker: "Suporte"
	},
	"prazo-de-entrega": {
		title: "Prazo de entrega",
		kicker: "Logística"
	},
	"trocas-e-garantia": {
		title: "Trocas e garantia",
		kicker: "Política"
	},
	privacidade: {
		title: "Privacidade",
		kicker: "Legal"
	},
	termos: {
		title: "Termos",
		kicker: "Legal"
	},
	contato: {
		title: "Fale conosco",
		kicker: "Contato"
	},
	reembolso: {
		title: "Reembolso",
		kicker: "Política"
	}
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatBRL(value) {
	return value.toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-pGuTO8jO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-3xl font-semibold",
				children: "Essa página não existe"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Volta pra loja — os 4 que resolvem o apê estão lá."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/collections/$slug",
				params: { slug: "pets" },
				className: "mt-8 inline-flex min-h-12 items-center justify-center rounded-md bg-primary px-6 text-sm font-semibold text-primary-fg",
				children: "Ver os 4 mais vendidos"
			})
		]
	});
}
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function AnnouncementBar() {
	const loop = [
		...ANNOUNCEMENTS,
		...ANNOUNCEMENTS,
		...ANNOUNCEMENTS
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative overflow-hidden bg-fg text-primary-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/collections/$slug",
			params: { slug: "pets" },
			className: "flex min-h-10 items-center",
			"aria-label": "Ofertas da loja",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ac-marquee flex w-max gap-10 py-2.5 pr-10 text-[11px] font-semibold tracking-[0.14em] uppercase",
				children: loop.map((msg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0",
					children: msg
				}, `${msg}-${i}`))
			})
		})
	});
}
var useCart = create()(persist((set, get) => ({
	lines: [],
	open: false,
	searchOpen: false,
	setOpen: (open) => set({ open }),
	setSearchOpen: (searchOpen) => set({ searchOpen }),
	add: (handle, qty = 1) => {
		const lines = [...get().lines];
		const i = lines.findIndex((l) => l.handle === handle);
		if (i >= 0) lines[i] = {
			handle,
			qty: lines[i].qty + qty
		};
		else lines.push({
			handle,
			qty
		});
		set({
			lines,
			open: true
		});
	},
	setQty: (handle, qty) => {
		if (qty <= 0) {
			set({ lines: get().lines.filter((l) => l.handle !== handle) });
			return;
		}
		set({ lines: get().lines.map((l) => l.handle === handle ? {
			...l,
			qty
		} : l) });
	},
	remove: (handle) => set({ lines: get().lines.filter((l) => l.handle !== handle) }),
	clear: () => set({ lines: [] })
}), {
	name: "auconforto-cart",
	partialize: (s) => ({ lines: s.lines })
}));
function cartCount(lines) {
	return lines.reduce((n, l) => n + l.qty, 0);
}
function cartSubtotal(lines) {
	return lines.reduce((n, l) => {
		const p = getProduct(l.handle);
		return n + (p ? p.price * l.qty : 0);
	}, 0);
}
var SHIPPING_FLAT = 9.9;
var PIX_OFF = .05;
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setHydrated(true), []);
	return hydrated;
}
function CartDrawer() {
	const open = useCart((s) => s.open);
	const setOpen = useCart((s) => s.setOpen);
	const rawLines = useCart((s) => s.lines);
	const setQty = useCart((s) => s.setQty);
	const remove = useCart((s) => s.remove);
	const lines = useHydrated() ? rawLines : [];
	const subtotal = cartSubtotal(lines);
	const ship = subtotal === 0 ? 0 : subtotal >= 149 ? 0 : SHIPPING_FLAT;
	const pix = subtotal * (1 - PIX_OFF);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `fixed inset-0 z-50 ${open ? "pointer-events-auto" : "pointer-events-none"}`,
		"aria-hidden": !open,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `absolute inset-0 bg-fg/40 transition-opacity duration-200 ${open ? "opacity-100" : "opacity-0"}`,
			onClick: () => setOpen(false),
			"aria-label": "Fechar carrinho"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: `absolute top-0 right-0 flex h-full w-full max-w-md flex-col bg-surface shadow-[var(--shadow-border)] transition-transform duration-300 ease-out ${open ? "translate-x-0" : "translate-x-full"}`,
			role: "dialog",
			"aria-label": "Carrinho",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold",
						children: "Carrinho"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center",
						onClick: () => setOpen(false),
						"aria-label": "Fechar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto px-5 py-4",
					children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-sm text-muted",
						children: "Carrinho vazio. Os 4 que resolvem o apê estão na loja."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-5",
						children: lines.map((line) => {
							const p = getProduct(line.handle);
							if (!p) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: p.image,
									alt: "",
									className: "size-20 rounded-md object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: p.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm tabular-nums",
											children: formatBRL(p.price)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "inline-flex size-9 items-center justify-center rounded-sm border border-border",
													onClick: () => setQty(line.handle, line.qty - 1),
													"aria-label": "Diminuir",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-6 text-center text-sm tabular-nums",
													children: line.qty
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "inline-flex size-9 items-center justify-center rounded-sm border border-border",
													onClick: () => setQty(line.handle, line.qty + 1),
													"aria-label": "Aumentar",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "ml-auto text-xs text-muted underline",
													onClick: () => remove(line.handle),
													children: "Remover"
												})
											]
										})
									]
								})]
							}, line.handle);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border px-5 py-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatBRL(subtotal)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Frete"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: subtotal === 0 ? "—" : ship === 0 ? "Grátis" : formatBRL(ship)
							})]
						}),
						subtotal > 0 && subtotal < 149 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								"Falta ",
								formatBRL(149 - subtotal),
								" pro frete grátis."
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm font-medium",
							children: ["Pix com 5% off: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatBRL(pix)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collections/$slug",
							params: { slug: "pets" },
							onClick: () => setOpen(false),
							className: "mt-4 flex min-h-12 items-center justify-center rounded-md bg-primary text-sm font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]",
							children: lines.length ? "Fechar no Pix (5% off)" : "Ver os 4 mais vendidos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-[11px] text-muted",
							children: "Cupom VOLTA10 na primeira compra. Garantia de 7 dias."
						})
					]
				})
			]
		})]
	});
}
function SearchDialog() {
	const open = useCart((s) => s.searchOpen);
	const setOpen = useCart((s) => s.setSearchOpen);
	const [q, setQ] = (0, import_react.useState)("");
	const results = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		if (!s) return PRODUCTS;
		return PRODUCTS.filter((p) => p.title.toLowerCase().includes(s) || p.short.toLowerCase().includes(s) || p.pain.toLowerCase().includes(s));
	}, [q]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-fg/40",
			"aria-label": "Fechar busca",
			onClick: () => setOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto mt-16 w-[min(640px,calc(100%-2rem))] rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 rounded-md border border-border bg-bg px-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Buscar produto, dor, pet…",
						className: "h-12 w-full bg-transparent text-base outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-10 items-center justify-center",
						onClick: () => setOpen(false),
						"aria-label": "Fechar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 max-h-[50vh] overflow-y-auto",
				children: [results.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/products/$handle",
					params: { handle: p.handle },
					onClick: () => setOpen(false),
					className: "flex min-h-16 items-center gap-3 rounded-md px-2 py-2 hover:bg-bg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.image,
							alt: "",
							className: "size-12 rounded-sm object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-muted",
								children: p.short
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm tabular-nums",
							children: formatBRL(p.price)
						})
					]
				}) }, p.handle)), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-2 py-8 text-sm text-muted",
					children: "Nada com esse termo."
				}) : null]
			})]
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-8 border-t border-border bg-fg text-primary-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold",
					children: "AuConforto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xs text-sm leading-relaxed text-primary-fg/70",
					children: "Conforto pra pets em apartamento. Pix + cartão 3x, rastreio incluso."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.16em] uppercase text-primary-fg/50",
					children: "Loja"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collections/$slug",
							params: { slug: "pets" },
							className: "hover:underline",
							children: "Todos os produtos"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collections/$slug",
							params: { slug: "gatos" },
							className: "hover:underline",
							children: "Gatos"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "rastrear-pedido" },
							className: "hover:underline",
							children: "Rastrear pedido"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "contato" },
							className: "hover:underline",
							children: "Fale conosco"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.16em] uppercase text-primary-fg/50",
					children: "Ajuda"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "prazo-de-entrega" },
							className: "hover:underline",
							children: "Prazo de entrega"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "trocas-e-garantia" },
							className: "hover:underline",
							children: "Trocas e garantia"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "privacidade" },
							className: "hover:underline",
							children: "Privacidade"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "termos" },
							className: "hover:underline",
							children: "Termos"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: "reembolso" },
							className: "hover:underline",
							children: "Reembolso"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/codigo-shopify",
							className: "text-primary-fg/70 hover:underline",
							children: "Código do tema Dawn"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-white/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 sm:flex-row sm:items-center sm:justify-between sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-2 text-[11px] font-semibold tracking-wider uppercase text-primary-fg/55",
					children: [
						"Pix",
						"Visa",
						"Mastercard",
						"Mercado Pago"
					].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm border border-white/15 px-2 py-1",
						children: p
					}, p))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-primary-fg/55",
					children: "© AuConforto — CNPJ em regularização MEI. Suporte em até 24h úteis."
				})]
			})
		})]
	});
}
var NAV = [
	{
		label: "Início",
		href: "/",
		to: "/"
	},
	{
		label: "Loja",
		href: "/collections/pets",
		to: "/collections/$slug",
		params: { slug: "pets" }
	},
	{
		label: "Gatos",
		href: "/collections/gatos",
		to: "/collections/$slug",
		params: { slug: "gatos" }
	},
	{
		label: "Rastrear Pedido",
		href: "/pages/rastrear-pedido",
		to: "/pages/$slug",
		params: { slug: "rastrear-pedido" }
	},
	{
		label: "Ajuda",
		href: "/pages/ajuda",
		to: "/pages/$slug",
		params: { slug: "ajuda" }
	}
];
function SiteHeader() {
	const [menu, setMenu] = (0, import_react.useState)(false);
	const lines = useCart((s) => s.lines);
	const setOpen = useCart((s) => s.setOpen);
	const setSearchOpen = useCart((s) => s.setSearchOpen);
	const count = useHydrated() ? cartCount(lines) : 0;
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-bg/92 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:h-[4.5rem] sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-md text-fg md:hidden",
					"aria-label": menu ? "Fechar menu" : "Abrir menu",
					onClick: () => setMenu((v) => !v),
					children: menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "font-display text-[1.35rem] font-semibold tracking-tight text-fg sm:text-[1.55rem]",
					onClick: () => setMenu(false),
					children: "AuConforto"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ml-8 hidden items-center gap-6 md:flex",
					children: NAV.map((item) => {
						const active = pathname === item.href;
						if (item.to === "/") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: cn("text-sm font-medium tracking-wide text-muted transition-colors duration-150", active ? "text-fg" : "hover:text-fg"),
							children: item.label
						}, item.label);
						if (item.to === "/collections/$slug") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collections/$slug",
							params: { slug: item.params.slug },
							className: cn("text-sm font-medium tracking-wide text-muted transition-colors duration-150", active ? "text-fg" : "hover:text-fg"),
							children: item.label
						}, item.label);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pages/$slug",
							params: { slug: item.params.slug },
							className: cn("text-sm font-medium tracking-wide text-muted transition-colors duration-150", active ? "text-fg" : "hover:text-fg"),
							children: item.label
						}, item.label);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center rounded-md text-fg",
						"aria-label": "Buscar",
						onClick: () => setSearchOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative inline-flex size-11 items-center justify-center rounded-md text-fg",
						"aria-label": "Abrir carrinho",
						onClick: () => setOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute top-1.5 right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-fg tabular-nums",
							children: count
						}) : null]
					})]
				})
			]
		}), menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "border-t border-border bg-bg px-4 py-3 md:hidden",
			children: [NAV.map((item) => item.to === "/" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "flex min-h-12 items-center border-b border-border text-base font-medium text-fg last:border-0",
				onClick: () => setMenu(false),
				children: item.label
			}, item.label) : item.to === "/collections/$slug" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/collections/$slug",
				params: { slug: item.params.slug },
				className: "flex min-h-12 items-center border-b border-border text-base font-medium text-fg last:border-0",
				onClick: () => setMenu(false),
				children: item.label
			}, item.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/pages/$slug",
				params: { slug: item.params.slug },
				className: "flex min-h-12 items-center border-b border-border text-base font-medium text-fg last:border-0",
				onClick: () => setMenu(false),
				children: item.label
			}, item.label)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/codigo-shopify",
				className: "flex min-h-12 items-center text-sm font-medium text-muted",
				onClick: () => setMenu(false),
				children: "Código Shopify (Dawn)"
			})]
		}) : null]
	});
}
function StoreShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnnouncementBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { className: "!bg-surface !text-fg !border-border !shadow-[var(--shadow-border)]" }
			})
		]
	});
}
var styles_default = "/assets/styles-3yU4pOHi.css";
var APP_NAME = "AuConforto";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Conforto pra pets em apartamento. Escova a vapor, pente mágico, moinho giratório e tapete gel. Pix com desconto, rastreio incluso."
			},
			{
				name: "theme-color",
				content: "#B54A2A"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-dvh bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-BYLp62rV.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./codigo-shopify-DztaoyoA.mjs");
var Route$3 = createFileRoute("/codigo-shopify")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./collections._slug-CwT-R435.mjs");
var Route$2 = createFileRoute("/collections/$slug")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./pages._slug-Bw3p6r3r.mjs");
var Route$1 = createFileRoute("/pages/$slug")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./products._handle-CjaQozIZ.mjs");
var Route = createFileRoute("/products/$handle")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	CodigoShopifyRoute: Route$3.update({
		id: "/codigo-shopify",
		path: "/codigo-shopify",
		getParentRoute: () => Route$5
	}),
	CollectionsSlugRoute: Route$2.update({
		id: "/collections/$slug",
		path: "/collections/$slug",
		getParentRoute: () => Route$5
	}),
	PagesSlugRoute: Route$1.update({
		id: "/pages/$slug",
		path: "/pages/$slug",
		getParentRoute: () => Route$5
	}),
	ProductsHandleRoute: Route.update({
		id: "/products/$handle",
		path: "/products/$handle",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound
	});
}
//#endregion
export { useCart as a, HELP_PAGES as c, TRUST as d, cn as f, productsByHandles as h, Route$2 as i, PRODUCTS as l, getProduct as m, Route as n, COLLECTIONS as o, formatBRL as p, Route$1 as r, FAQS as s, router_exports as t, PRODUCT_ORDER_HOME as u };
