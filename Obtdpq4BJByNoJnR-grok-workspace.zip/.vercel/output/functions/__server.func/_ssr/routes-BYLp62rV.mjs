import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, d as CreditCard, n as Truck, u as House } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { d as TRUST, h as productsByHandles, u as PRODUCT_ORDER_HOME } from "./router-pGuTO8jO.mjs";
import { t as ProductCard } from "./product-card-D8cUPilU.mjs";
import { t as FaqList } from "./faq-list-7l8YLF9Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYLp62rV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	truck: Truck,
	card: CreditCard,
	shield: Shield,
	home: House
};
function HomePage() {
	const products = productsByHandles(PRODUCT_ORDER_HOME);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate min-h-[78vh] overflow-hidden bg-fg text-primary-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/hero.jpg",
					alt: "Gato e cão no sofá de um apartamento",
					className: "absolute inset-0 h-full w-full object-cover outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-fg/78 via-fg/45 to-fg/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-4 py-14 sm:px-6 md:justify-center md:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.2em] text-primary-fg/75 uppercase",
							children: "AuConforto · pets em apartamento"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-4 max-w-3xl text-[2.1rem] leading-[1.12] font-semibold tracking-tight sm:text-5xl md:text-[3.4rem]",
							children: "Apartamento com pet não precisa viver com pelo, calor e tédio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base leading-relaxed text-primary-fg/82 sm:text-lg",
							children: "4 soluções testadas pra cães e gatos em apê. Pix com desconto, rastreio incluso, 7 dias de garantia."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/collections/$slug",
								params: { slug: "pets" },
								className: "inline-flex min-h-12 items-center justify-center rounded-md bg-primary px-6 text-sm font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]",
								children: "Ver os 4 mais vendidos"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pages/$slug",
								params: { slug: "rastrear-pedido" },
								className: "inline-flex min-h-12 items-center justify-center rounded-md border border-white/25 bg-fg/20 px-6 text-sm font-semibold text-primary-fg backdrop-blur-sm transition-transform duration-150 active:scale-[0.96]",
								children: "Rastrear meu pedido"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-primary-fg/75",
							children: "Pix com desconto · 8–15 dias úteis com rastreio · 7 dias contra defeito"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-4",
				children: TRUST.map((item) => {
					const Icon = ICONS[item.icon];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 md:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "mt-0.5 size-5 shrink-0 text-primary",
							strokeWidth: 1.6
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: item.text
						})] })]
					}, item.title);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
					children: "Coleção em destaque"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-2 max-w-2xl text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "Os 4 que mais saem pra quem mora em apê"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-muted",
					children: "Escolhe pela tua dor. Frete grátis acima de R$149."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
					children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
						product: p,
						featured: true
					}, p.handle))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/collections/$slug",
						params: { slug: "pets" },
						className: "inline-flex min-h-11 items-center justify-center rounded-md border border-border bg-surface px-5 text-sm font-semibold transition-transform duration-150 active:scale-[0.96]",
						children: "Ver tudo"
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-muted uppercase",
						children: "Por que funciona"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mt-2 text-3xl font-semibold tracking-tight sm:text-4xl",
						children: "Antes / depois no sofá do apê"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-12 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "grid gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/antes-pelo.jpg",
									alt: "Sofá coberto de pelo",
									className: "aspect-[4/3] w-full rounded-lg object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "mt-2 text-xs tracking-wide text-muted uppercase",
									children: "Antes"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/depois-pelo.jpg",
									alt: "Sofá limpo com gato calmo",
									className: "aspect-[4/3] w-full rounded-lg object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "mt-2 text-xs tracking-wide text-muted uppercase",
									children: "Depois"
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-semibold tracking-tight",
									children: "5 min por dia, 80% menos pelo no sofá"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted",
									children: "Pente + Escova Vapor tiram o subpelo que aspirador não pega. Sem puxar, sem machucar. Gato ronrona, cachorro fica quieto."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/products/$handle",
									params: { handle: "escova-a-vapor" },
									className: "mt-5 inline-flex min-h-11 items-center text-sm font-semibold text-primary underline-offset-4 hover:underline",
									children: "Quero casa sem pelo"
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "grid gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/moinho-lifestyle.jpg",
								alt: "Gato brincando com o moinho giratório",
								className: "aspect-[4/3] w-full rounded-lg object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-semibold tracking-tight",
									children: "Gato sozinho não precisa destruir o sofá"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted",
									children: "Moinho cansa em 15 min sem você. Tapete Gel alivia o calor sem molhar, sem geladeira, sem energia."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/products/$handle",
									params: { handle: "moinho-giratorio" },
									className: "mt-5 inline-flex min-h-11 items-center text-sm font-semibold text-primary underline-offset-4 hover:underline",
									children: "Quero gato tranquilo"
								})
							] })]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Perguntas de quem mora em apê"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 mb-8 text-muted",
					children: "As mesmas 5 do suporte. Sem enrolação."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, {})
	] });
}
function Newsletter() {
	const [email, setEmail] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border bg-fg text-primary-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl px-4 py-16 text-center sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Ganha 10% off na primeira compra"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-primary-fg/70",
					children: "Deixa teu e-mail e recebe VOLTA10 + rastreio sem enrolação."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					onSubmit: (e) => {
						e.preventDefault();
						toast.success("Cupom VOLTA10 enviado. Olha o e-mail.");
						setEmail("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "home-email",
							children: "E-mail"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "home-email",
							type: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							placeholder: "teu@email.com",
							className: "h-12 flex-1 rounded-md border border-white/15 bg-white/5 px-4 text-primary-fg outline-none placeholder:text-primary-fg/40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "inline-flex h-12 items-center justify-center rounded-md bg-primary px-6 text-sm font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]",
							children: "Quero meu cupom"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { HomePage as component };
