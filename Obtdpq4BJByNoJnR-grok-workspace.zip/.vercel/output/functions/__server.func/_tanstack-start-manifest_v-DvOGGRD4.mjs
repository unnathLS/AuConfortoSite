//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DvOGGRD4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/codigo-shopify",
			"/collections/$slug",
			"/pages/$slug",
			"/products/$handle"
		],
		preloads: [
			"/assets/index-Bjhz76Ty.js",
			"/assets/jsx-runtime-Cltr0gcK.js",
			"/assets/utils-DihTU2Vy.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bjhz76Ty.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-qPvwkHjW.js",
			"/assets/faq-list-si0u9Lwh.js",
			"/assets/product-card-DJCR-uJZ.js"
		]
	},
	"/codigo-shopify": {
		filePath: "/workspace/src/routes/codigo-shopify.tsx",
		children: void 0,
		preloads: ["/assets/codigo-shopify-DHC8jPCs.js", "/assets/check-CBnD1qPF.js"]
	},
	"/collections/$slug": {
		filePath: "/workspace/src/routes/collections.$slug.tsx",
		children: void 0,
		preloads: ["/assets/collections._slug-Bl_QY_Wm.js", "/assets/product-card-DJCR-uJZ.js"]
	},
	"/pages/$slug": {
		filePath: "/workspace/src/routes/pages.$slug.tsx",
		children: void 0,
		preloads: ["/assets/pages._slug-CYnjbjkQ.js", "/assets/faq-list-si0u9Lwh.js"]
	},
	"/products/$handle": {
		filePath: "/workspace/src/routes/products.$handle.tsx",
		children: void 0,
		preloads: ["/assets/products._handle-DcChVJDC.js", "/assets/check-CBnD1qPF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
